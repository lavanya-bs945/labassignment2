 <?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'];
 $email = $_POST['email'];
  $dob = $_POST['dob'];
  $password = $_POST['password'];

  // Simple validation
 if (empty($name) || empty($email) || empty($dob) || empty($password)) {
   echo "Please fill in all fields.";
  } else {
    echo "Registration Successful!<br>";
    echo "Name: $name<br>";
    echo "Email: $email<br>";
  echo "Date of Birth: $dob<br>";
    // You can add more logic like storing the data in a database
  }
}
?> 

